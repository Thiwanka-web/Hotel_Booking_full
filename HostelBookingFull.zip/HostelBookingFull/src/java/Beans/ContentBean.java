/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import HotelDAO.ContentDAO;



/**
 *
 * @author ASUS
 */
public class ContentBean {
    
    private String pos;
    private String content;
    private String id;

    public void setPos(String pos) {
        this.pos = pos;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPos() {
        return pos;
    }

    public String getContent() {
        return content;
    }

    public String getId() {
        return id;
    }
    
    public void add()
    {
        ContentDAO dao = new ContentDAO();
        dao.addDate(this);
    }
    
    public void update()
    {
        ContentDAO dao = new ContentDAO();
        dao.update(this);
    }
    
    public void delete()
    {
        ContentDAO dao = new ContentDAO();
        dao.remove(this);
    }
    
}
