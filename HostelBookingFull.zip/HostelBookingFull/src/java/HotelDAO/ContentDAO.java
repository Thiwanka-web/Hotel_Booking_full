/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HotelDAO;

import Beans.ContentBean;
import Services.DBConnection;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ContentDAO {
    
    DBConnection dbcon = new DBConnection();
    Connection con;
    Statement stmt;
    
    public void addDate(ContentBean bean)
    {
        String pos= bean.getPos();
        String cion = bean.getContent();
        
         Statement smt;
        con= dbcon.getConnection();
        
         try {
            smt= con.createStatement();
            String query="INSERT INTO content(pos,body) VALUES('"+pos+"','"+cion+"')";
            smt.execute(query);
            
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void update(ContentBean bean)
    {
        String id= bean.getId();
        String pos= bean.getPos();
        String cion = bean.getContent();
        
        Statement smt;
        con= dbcon.getConnection();
        
        try {
            smt= con.createStatement();
            String query="UPDATE content SET pos='"+pos+"',body='"+cion+"' WHERE id='"+id+"' ";
            smt.execute(query);
            
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void remove(ContentBean bean)
    {
        String id= bean.getId();
        Statement smt;
        con= dbcon.getConnection();
        try {
                smt= con.createStatement();
                String qery="DELETE FROM content WHERE id='"+id+"'";
                smt.execute(qery);
            
                } catch (SQLException ex) {
                Logger.getLogger(RegistrationDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
}
